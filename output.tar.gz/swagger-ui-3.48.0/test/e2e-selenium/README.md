These tests are currently broken, and need to be either updated or migrated into
`../e2e-cypress`.
