import SwaggerUI from "./core"

export default SwaggerUI
